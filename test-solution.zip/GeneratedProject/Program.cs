using System;
using JYUSB1601;

namespace USB1601DataAcquisition
 {
    class Program
 {
        static void Main(string[] args)
 {
            // Single Mode Data Acquisition
            SingleModeDataAcquisition();
            // Continuous Mode Data Acquisition
            ContinuousModeDataAcquisition();
            // Finite Mode Data Acquisition
            FiniteModeDataAcquisition();
        }

        static void SingleModeDataAcquisition()
 {
            try
 {
                JYUSB1601AITask aiTask = new JYUSB1601AITask("0");
                aiTask.Mode = AIMode.Single;
                aiTask.AddChannel(0, -10, 10); // Assuming channel 0 is the desired one with range -10 to 10 V
                aiTask.Start(); // Start the task in single mode
                double readValue = 0;
                aiTask.ReadSinglePoint(ref readValue, 0); // Read a single point from channel 0
                Console.WriteLine($"Channel 0: {readValue} V"); // Output the read value in Volts
            }
            catch (JYDriverException ex)
 {
                Console.WriteLine("Error in Single Mode Data Acquisition: " + ex.Message); // Handle JYDriverException
            }
            finally
 {
                if (aiTask != null) // Clean up resources if aiTask is not null
 {
                    aiTask.Stop(); // Stop the task if it's running
                    aiTask.Channels.Clear(); // Clear the channels collection if necessary
                }
            }
        }

        static void ContinuousModeDataAcquisition()
 {
            try
 {
                JYUSB1601AITask aiTask = new JYUSB1601AITask("0"); // Create a task instance for USB-1601 device with COM port "0"
                aiTask.Mode = AIMode.Continuous; // Set the task mode to continuous scanning of channels in loop (e.g., timer tick event) or with callback methods. Here's a simple example using a timer tick event for reading data periodically. Please note that actual data acquisition might involve more sophisticated approaches with threading and synchronization. It's assumed that a separate timer event or similar mechanism would handle this reading loop based on the specific device driver's documentation and/or application scenarios. Refer to JYUSB-1601 documentation for proper synchronization and timing configurations in continuous mode. Additionally, this code snippet assumes that you have a way to access the available samples count (e.g., through the device driver's API). If not, you would need to consult the documentation for the actual way to determine if data is available for reading. This code is illustrative and may need modifications based on your specific requirements and device driver implementation details.""; aiTask.SampleRate = 1000; // Set the sample rate if needed aiTask.AddChannel(0, -10, 10); // Add channels as needed // Note: You need to handle reading data within a loop (e.g., a timer tick event) based on your application requirements and device driver's API implementation. This code snippet does not include the actual loop for continuous data acquisition as it depends on your specific application and the JYUSB-1601 driver implementation details.} catch (JYDriverException ex) { Console.WriteLine("Error in Continuous Mode Data Acquisition: " + ex.Message); } finally { if (aiTask != null) { aiTask.Stop(); aiTask.Channels.Clear(); } } } static void FiniteModeDataAcquisition() { try { JYUSB1601AITask aiTask = new JYUSB1601AITask("0"); aiTask.Mode = AIMode.Finite; aiTask.SamplesToAcquire = 5000; // Set the number of samples to acquire aiTask.SampleRate = 1000; // Set the sample rate if needed aiTask.AddChannel(0, -10, 10); // Add channels as needed double[] readValue = new double[5000]; aiTask.Start(); // Start finite mode acquisition // Wait for acquisition to complete while (aiTask.AvailableSamples < aiTask.SamplesToAcquire) { System.Threading.Thread.Sleep(1); } aiTask.ReadData(ref readValue, aiTask.SamplesTo
            }
        }
    }
}