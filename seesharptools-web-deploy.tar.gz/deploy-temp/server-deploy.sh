#!/bin/bash

set -e

echo "🔧 安装必要的软件包..."
apt update
apt install -y nginx dotnet-runtime-9.0 curl

echo "📁 创建部署目录..."
mkdir -p /var/www/seesharpweb/frontend
mkdir -p /var/www/seesharpweb/backend
mkdir -p /etc/ssl/certs
mkdir -p /etc/ssl/private

echo "📦 部署文件..."
cp -r /tmp/deploy/frontend/* /var/www/seesharpweb/frontend/
cp -r /tmp/deploy/backend/* /var/www/seesharpweb/backend/
cp /tmp/deploy/ssl/www.alethealab.cn.pem /etc/ssl/certs/
cp /tmp/deploy/ssl/www.alethealab.cn.key /etc/ssl/private/

echo "🔐 设置文件权限..."
chown -R www-data:www-data /var/www/seesharpweb
chmod -R 755 /var/www/seesharpweb
chmod 600 /etc/ssl/private/www.alethealab.cn.key
chmod 644 /etc/ssl/certs/www.alethealab.cn.pem
chmod +x /var/www/seesharpweb/backend/SeeSharpBackend

echo "⚙️ 配置Nginx..."
cp /tmp/deploy/config/nginx-seesharpweb.conf /etc/nginx/sites-available/
ln -sf /etc/nginx/sites-available/nginx-seesharpweb.conf /etc/nginx/sites-enabled/
nginx -t
systemctl reload nginx

echo "🔧 配置systemd服务..."
cp /tmp/deploy/config/seesharpweb.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable seesharpweb
systemctl start seesharpweb

echo "🔥 配置防火墙..."
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 5000/tcp

echo "✅ 部署完成！"
echo "🌐 网站地址: https://www.alethealab.cn/seesharpweb"
echo "📊 后端API: https://www.alethealab.cn/seesharpweb/api"

echo "🔍 检查服务状态..."
systemctl status seesharpweb --no-pager
systemctl status nginx --no-pager

echo "🧪 测试连接..."
curl -k https://localhost/seesharpweb/ || echo "前端测试失败"
curl -k https://localhost/seesharpweb/api/weatherforecast || echo "后端API测试失败"
