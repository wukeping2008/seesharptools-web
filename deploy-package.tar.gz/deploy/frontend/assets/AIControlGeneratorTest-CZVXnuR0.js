var _=(m,t,e)=>new Promise((a,l)=>{var p=i=>{try{n(e.next(i))}catch(g){l(g)}},c=i=>{try{n(e.throw(i))}catch(g){l(g)}},n=i=>i.done?a(i.value):Promise.resolve(i.value).then(p,c);n((e=e.apply(m,t)).next())});import{b as S}from"./BackendApiService-DMdPzFET.js";import{d as M,E as w,c as u,a as o,R as h,o as d,_ as N,V as U,W as P,r as v,O as j,f,A as L,g as $,S as K,U as Y,w as D,Q as E,Y as x}from"./element-plus-ULPXOTbl.js";import{_ as I}from"./index-D2d8CDLs.js";const y=[{id:"gauge",name:"仪表盘",description:"圆形仪表盘，显示数值和刻度",code:`<template>
  <div class="gauge-container">
    <svg :width="size" :height="size" viewBox="0 0 200 200">
      <!-- 背景圆弧 -->
      <path
        :d="backgroundArc"
        fill="none"
        stroke="#e0e0e0"
        :stroke-width="strokeWidth"
      />
      <!-- 值圆弧 -->
      <path
        :d="valueArc"
        fill="none"
        :stroke="color"
        :stroke-width="strokeWidth"
        stroke-linecap="round"
      />
      <!-- 中心文本 -->
      <text x="100" y="110" text-anchor="middle" class="gauge-value">
        {{ value }}
      </text>
      <text x="100" y="130" text-anchor="middle" class="gauge-unit">
        {{ unit }}
      </text>
    </svg>
    <div class="gauge-title">{{ title }}</div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

interface Props {
  value: number
  min?: number
  max?: number
  unit?: string
  title?: string
  size?: number
  color?: string
}

const props = withDefaults(defineProps<Props>(), {
  min: 0,
  max: 100,
  unit: '',
  title: '仪表盘',
  size: 200,
  color: '#409eff'
})

const strokeWidth = 20
const radius = 80
const startAngle = -135
const endAngle = 135

const valueAngle = computed(() => {
  const percentage = (props.value - props.min) / (props.max - props.min)
  return startAngle + (endAngle - startAngle) * percentage
})

const polarToCartesian = (angle: number) => {
  const angleInRadians = (angle - 90) * Math.PI / 180
  return {
    x: 100 + radius * Math.cos(angleInRadians),
    y: 100 + radius * Math.sin(angleInRadians)
  }
}

const describeArc = (startAngle: number, endAngle: number) => {
  const start = polarToCartesian(endAngle)
  const end = polarToCartesian(startAngle)
  const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1"
  return [
    "M", start.x, start.y,
    "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y
  ].join(" ")
}

const backgroundArc = computed(() => describeArc(startAngle, endAngle))
const valueArc = computed(() => describeArc(startAngle, valueAngle.value))
<\/script>

<style scoped>
.gauge-container {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
}

.gauge-value {
  font-size: 32px;
  font-weight: bold;
  fill: #333;
}

.gauge-unit {
  font-size: 14px;
  fill: #666;
}

.gauge-title {
  margin-top: 10px;
  font-size: 16px;
  color: #333;
}
</style>`},{id:"led",name:"LED指示灯",description:"LED状态指示灯，支持多种颜色",code:`<template>
  <div class="led-container">
    <div 
      class="led"
      :class="{ 'led-on': isOn }"
      :style="{ backgroundColor: isOn ? color : '#ccc' }"
    >
      <div class="led-light" v-if="isOn"></div>
    </div>
    <div class="led-label">{{ label }}</div>
  </div>
</template>

<script setup lang="ts">
interface Props {
  isOn: boolean
  color?: string
  label?: string
}

withDefaults(defineProps<Props>(), {
  color: '#00ff00',
  label: 'LED'
})
<\/script>

<style scoped>
.led-container {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.led {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  border: 2px solid #999;
  position: relative;
  transition: all 0.3s ease;
}

.led-on {
  box-shadow: 0 0 10px currentColor;
}

.led-light {
  position: absolute;
  top: 4px;
  left: 4px;
  width: 8px;
  height: 8px;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 50%;
}

.led-label {
  font-size: 12px;
  color: #666;
}
</style>`},{id:"button",name:"按钮控件",description:"工业风格按钮",code:`<template>
  <button 
    class="industrial-button"
    :class="{ 'button-pressed': isPressed }"
    @mousedown="handleMouseDown"
    @mouseup="handleMouseUp"
    @mouseleave="handleMouseUp"
  >
    <span class="button-text">{{ text }}</span>
  </button>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface Props {
  text?: string
}

const props = withDefaults(defineProps<Props>(), {
  text: '按钮'
})

const emit = defineEmits<{
  click: []
}>()

const isPressed = ref(false)

const handleMouseDown = () => {
  isPressed.value = true
}

const handleMouseUp = () => {
  if (isPressed.value) {
    emit('click')
  }
  isPressed.value = false
}
<\/script>

<style scoped>
.industrial-button {
  padding: 12px 24px;
  background: linear-gradient(135deg, #f0f0f0 0%, #d0d0d0 100%);
  border: 2px solid #999;
  border-radius: 4px;
  cursor: pointer;
  user-select: none;
  transition: all 0.1s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.industrial-button:hover {
  background: linear-gradient(135deg, #f5f5f5 0%, #d5d5d5 100%);
}

.button-pressed {
  background: linear-gradient(135deg, #d0d0d0 0%, #b0b0b0 100%);
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.3);
  transform: translateY(1px);
}

.button-text {
  font-size: 14px;
  font-weight: 600;
  color: #333;
}
</style>`}];class Q{generateControl(t){return _(this,null,function*(){try{const e=yield S.post("/api/ai/generate-control",{description:t.description});return e.success&&e.code?e:(console.warn("Claude API调用失败，使用备用模板"),this.generateFromTemplate(t))}catch(e){return console.error("AI生成控件错误:",e),this.generateFromTemplate(t)}})}generateFromTemplate(t){try{const e=t.description.toLowerCase();let a;return e.includes("仪表")||e.includes("gauge")||e.includes("表盘")?a=y.find(l=>l.id==="gauge"):e.includes("led")||e.includes("指示灯")||e.includes("灯")?a=y.find(l=>l.id==="led"):(e.includes("按钮")||e.includes("button"))&&(a=y.find(l=>l.id==="button")),a?{success:!0,code:a.code}:{success:!0,code:y[0].code}}catch(e){return{success:!1,error:e instanceof Error?e.message:"生成失败"}}}getTemplates(){return y}}const O=new Q,H={class:"gauge-container"},J=["width","height"],X=["d"],Z=["d","stroke"],q={x:"100",y:"110","text-anchor":"middle",class:"gauge-value"},ee={x:"100",y:"130","text-anchor":"middle",class:"gauge-unit"},te={class:"gauge-title"},V=20,A=80,C=-135,F=135,se=M({__name:"GaugePreview",props:{value:{},min:{default:0},max:{default:100},unit:{default:""},title:{default:"仪表盘"},size:{default:200},color:{default:"#409eff"}},setup(m){const t=m,e=w(()=>{const n=(t.value-t.min)/(t.max-t.min);return C+(F-C)*n}),a=n=>{const i=(n-90)*Math.PI/180;return{x:100+A*Math.cos(i),y:100+A*Math.sin(i)}},l=(n,i)=>{const g=a(i),k=a(n),T=i-n<=180?"0":"1";return["M",g.x,g.y,"A",A,A,0,T,0,k.x,k.y].join(" ")},p=w(()=>l(C,F)),c=w(()=>l(C,e.value));return(n,i)=>(d(),u("div",H,[(d(),u("svg",{width:n.size,height:n.size,viewBox:"0 0 200 200"},[o("path",{d:p.value,fill:"none",stroke:"#e0e0e0","stroke-width":V},null,8,X),o("path",{d:c.value,fill:"none",stroke:n.color,"stroke-width":V,"stroke-linecap":"round"},null,8,Z),o("text",q,h(n.value),1),o("text",ee,h(n.unit),1)],8,J)),o("div",te,h(n.title),1)]))}}),ne=I(se,[["__scopeId","data-v-a0cc19e9"]]),oe={class:"led-container"},ae={key:0,class:"led-light"},le={class:"led-label"},re=M({__name:"LEDPreview",props:{isOn:{type:Boolean},color:{default:"#00ff00"},label:{default:"LED"}},setup(m){return(t,e)=>(d(),u("div",oe,[o("div",{class:U(["led",{"led-on":t.isOn}]),style:N({backgroundColor:t.isOn?t.color:"#ccc"})},[t.isOn?(d(),u("div",ae)):P("",!0)],6),o("div",le,h(t.label),1)]))}}),ie=I(re,[["__scopeId","data-v-81b81e36"]]),ce={class:"button-text"},de=M({__name:"ButtonPreview",props:{text:{default:"按钮"}},emits:["click"],setup(m,{emit:t}){const e=t,a=v(!1),l=()=>{a.value=!0},p=()=>{a.value&&e("click"),a.value=!1};return(c,n)=>(d(),u("button",{class:U(["industrial-button",{"button-pressed":a.value}]),onMousedown:l,onMouseup:p,onMouseleave:p},[o("span",ce,h(c.text),1)],34))}}),ue=I(de,[["__scopeId","data-v-60c90fa8"]]),pe={class:"ai-generator-page"},ge={class:"input-section"},ve={class:"template-section"},me={class:"template-list"},fe={key:0,class:"result-section"},he={class:"code-container"},be={class:"code-header"},_e={class:"code-block"},xe={class:"preview-section"},ye={class:"preview-container"},we={key:0,class:"preview-item"},ke={key:1,class:"preview-item"},Ae={key:2,class:"preview-item"},Ce=M({__name:"AIControlGeneratorTest",setup(m){const t=v(""),e=v(!1),a=v(""),l=v(""),p=v([]),c=v(""),n=v(!1),i=w(()=>n.value?"✅ 已配置Claude API，将使用真实AI生成控件":"⚠️ 未配置Claude API，将使用预定义模板（查看文档了解如何配置）"),g=w(()=>n.value?"success":"warning");j(()=>_(this,null,function*(){p.value=O.getTemplates();try{const r=yield S.get("/api/ai/status").catch(()=>null);n.value=(r==null?void 0:r.hasApiKey)||!1}catch(r){n.value=!1}}));const k=r=>{t.value=r.description,a.value=r.code,c.value=r.id},T=()=>_(this,null,function*(){if(!t.value.trim()){x.warning("请输入控件描述");return}e.value=!0,l.value="";try{const r=yield O.generateControl({description:t.value});if(r.success&&r.code){a.value=r.code;const s=t.value.toLowerCase();s.includes("led")||s.includes("灯")?c.value="led":s.includes("按钮")||s.includes("button")?c.value="button":c.value="gauge",x.success("控件生成成功！")}else l.value=r.error||"生成失败"}catch(r){l.value=r instanceof Error?r.message:"生成过程中发生错误"}finally{e.value=!1}}),G=()=>_(this,null,function*(){try{yield navigator.clipboard.writeText(a.value),x.success("代码已复制到剪贴板")}catch(r){x.error("复制失败")}}),R=()=>{x.info("按钮被点击了！")};return(r,s)=>{const B=$("el-alert"),W=$("el-input"),z=$("el-button");return d(),u("div",pe,[s[9]||(s[9]=o("h1",null,"AI控件生成器",-1)),f(B,{title:i.value,type:g.value,closable:!1,"show-icon":"",style:{"margin-bottom":"20px"}},null,8,["title","type"]),o("div",ge,[s[4]||(s[4]=o("h2",null,"描述您需要的控件",-1)),f(W,{modelValue:t.value,"onUpdate:modelValue":s[0]||(s[0]=b=>t.value=b),type:"textarea",rows:3,placeholder:"例如：创建一个仪表盘显示温度"},null,8,["modelValue"]),o("div",ve,[s[2]||(s[2]=o("h3",null,"或选择预定义模板：",-1)),o("div",me,[(d(!0),u(K,null,Y(p.value,b=>(d(),L(z,{key:b.id,onClick:Pe=>k(b),size:"small"},{default:D(()=>[E(h(b.name),1)]),_:2},1032,["onClick"]))),128))])]),f(z,{type:"primary",onClick:T,loading:e.value,disabled:!t.value.trim()},{default:D(()=>s[3]||(s[3]=[E(" 生成控件 ")])),_:1,__:[3]},8,["loading","disabled"])]),a.value?(d(),u("div",fe,[s[8]||(s[8]=o("h2",null,"生成的控件代码",-1)),o("div",he,[o("div",be,[s[6]||(s[6]=o("span",null,"Vue组件代码",-1)),f(z,{size:"small",onClick:G},{default:D(()=>s[5]||(s[5]=[E("复制代码")])),_:1,__:[5]})]),o("pre",_e,[o("code",null,h(a.value),1)])]),o("div",xe,[s[7]||(s[7]=o("h3",null,"控件预览",-1)),o("div",ye,[c.value==="gauge"?(d(),u("div",we,[f(ne,{value:42,unit:"°C",title:"温度"})])):c.value==="led"?(d(),u("div",ke,[f(ie,{"is-on":!0,color:"#00ff00",label:"状态"})])):c.value==="button"?(d(),u("div",Ae,[f(ue,{text:"点击我",onClick:R})])):P("",!0)])])])):P("",!0),l.value?(d(),L(B,{key:1,title:l.value,type:"error",closable:!0,onClose:s[1]||(s[1]=b=>l.value="")},null,8,["title"])):P("",!0)])}}}),$e=I(Ce,[["__scopeId","data-v-bfe27764"]]);export{$e as default};
//# sourceMappingURL=AIControlGeneratorTest-CZVXnuR0.js.map
